/**
 * Represents a server in this project
 * @author Adam
 *
 */
public class Server 
{
	//The time taken to execute something
	private int executionTime;
	//The current Request being run on this server
	private Request currentRequest;
	//The current time of the server
	private int currentTime;
	
	public Server(int executionTime)
	{
		this.executionTime = executionTime;
		this.currentRequest = null;
		this.currentTime = 0;
	}
	
	/**
	 * Attempts to add a request to the server.
	 * @param request The request to add
	 * @return true if server can compute the request, false otherwise
	 */
	public boolean addRequest(Request request)
	{
		if ((this.currentRequest != null) || (this.currentTime >= this.executionTime))
		{
			this.currentRequest = request;
			this.currentTime = 0; //Reset the current time
			return true;
		}
		else
			return false;
	}
	
	/**
	 * Mimics doing some work on a request, just increments
	 * the current time
	 */
	public void execute()
	{
		this.currentTime++;
		if (this.currentRequest == null)
			this.executionTime++;
		
		if (this.currentTime >= this.executionTime)
		{
			this.currentRequest.setRequestTimeFinish(this.currentTime);
			this.executionTime += this.currentTime;
			this.currentRequest = null;
		}
	}
	
	public Request getCurrentRequest()
	{
		return this.currentRequest;
	}
	
	/**
	 * Shows whether this Server is idle
	 * @return true for saying the server is idle, false otherwise.
	 */
	public boolean isIdle()
	{
		return this.currentRequest == null;
	}
}
