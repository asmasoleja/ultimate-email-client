import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

/**
 * Used to simulate processes being executed on Servers
 * @author Adam
 *
 */
public class Simulator 
{
	//The max value the time can reach
	private static final int MAX_TIME_UNITS = 100000000;
	
	//The current time value
	private int currentTime;
	//The requests made
	private int requests;
	//The request rejected
	private int rejectedRequests;
	//The average queue size
	private float averageQueueSize;
	
	//The execution time
	private int executionTime;
	//The arrival rate
	private int arrivalRate;
	//The number of servers
	private int noOfServers;
	//All the servers in the system
	private Server[] servers;
	//The queue size
	private int queueSize;
	//The queue
	private Queue<Request> queue;
	
	//The number of requests needed
	private int noOfRequests;
	//The times of the request
	private int requestTimes[];
	
	BufferedWriter log;
	
	public Simulator(int executionTime, int arrivalRate, int noOfServers, int queueSize) 
	{
		this.executionTime = executionTime;
		this.arrivalRate = arrivalRate;
		this.noOfServers = noOfServers;
		this.queueSize = queueSize;
		
		this.servers = new Server[this.noOfServers];
		for (int i = 0; i < servers.length; i++)
			this.servers[i] = new Server(this.executionTime);
		
		this.queue = new LinkedList<Request>();
		
		this.noOfRequests = MAX_TIME_UNITS / this.arrivalRate;
		
		int timeBetweenRequest = MAX_TIME_UNITS / this.noOfRequests;
		this.requestTimes = new int[this.noOfRequests];
		
		//Create a new random number generator and seed it with the current time.
		Random generator = new Random();
		
		System.out.println("NoOfRequests: " + noOfRequests + " Time between requests: " + timeBetweenRequest);
		//Generate the request times
		int lastValue = 0;
		for (int i = 0; i < this.requestTimes.length; i++)
		{
			this.requestTimes[i] = 1 + generator.nextInt(timeBetweenRequest) + lastValue;
			lastValue = this.requestTimes[i];
			//System.out.println((i - timeBetweenRequest) + ") " + requestTimes[i - timeBetweenRequest]);
		}
		
		try {
			log = new BufferedWriter(new FileWriter("log.txt"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		/*for (int i = 0; i < requestTimes.length; i++)
			try {
				log.write(Integer.toString(requestTimes[i]));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
		
	}
	
	/**
	 * Runs the simulation until complete
	 */
	public void runSimulation()
	{
		//We need to loop while we're not at the maximum value we can reach
		int count = 0;
		System.out.println("RequestTimes: " + requestTimes[0]);
		System.out.println("request count: " + requestTimes.length);
		System.out.println("Last: " + requestTimes[requestTimes.length - 1]);
		while (this.currentTime != MAX_TIME_UNITS)
		{
			//System.out.println(count);
			if (this.currentTime >= this.requestTimes[count])
			{
				//Increment requests made
				this.requests++;
				count++;
				//Send a request, only accept if space in queue
				if (queue.size() < this.queueSize)
				{
					Request request = new Request(this.currentTime);
					this.queue.add(request);
				}
				else
				{
					this.rejectedRequests++;
				}
			}
				
			//Try to assign requests to servers
			if (!this.queue.isEmpty())
			{
				for (Server server : servers)
				{
					//If we can add a request to a server, remove it from
					//the queue
					if (server.addRequest(this.queue.peek()))
						this.queue.remove();
				}
			}
			
			//For each server, execute (increment time).
			for (Server server : servers)
				server.execute();
			
			//Finally, increment the time
			this.currentTime++;
		}
		
		System.out.println("Finished @ time: " + currentTime);
		System.out.println("Requests made: " + this.requests);
		System.out.println("Requests rejected: " + this.rejectedRequests);
		System.out.println("As a percentage: " + (100 * ((float)this.rejectedRequests / (float)this.requests)));
		
		try {
			log.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	

}
